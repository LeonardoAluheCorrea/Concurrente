/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salmanFaiParcial2;

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Admin
 */
public class Auto implements Runnable{
    Transbordador transbordador;
    private boolean subioTransbordador = false;
    
    public Auto(Transbordador transbordador){
        this.transbordador = transbordador;
    }
    
    public void run(){
        try {
            Thread.sleep(new Random().nextInt(5000));           //Simula el tiempo que le toma al auto llegar hasta el punto de embarque
        } catch (InterruptedException ex) {
            Logger.getLogger(Auto.class.getName()).log(Level.SEVERE, null, ex);
        }
        while(!subioTransbordador){            
            System.out.println(Thread.currentThread().getName() + " intenta subir");
            transbordador.subir(this);
        }
        transbordador.bajar();          //Luego continua hacia el oeste (hielo muere)
    }    
    
    public void subio(boolean subioAlTransbordador){
        subioTransbordador = subioAlTransbordador;
    }    
}