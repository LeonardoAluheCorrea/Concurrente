/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salmanFaiParcial2;

import java.util.Random;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Admin
 */
public class BufferOscilante{
    private Lista colaExtractor;
    private Lista colaInsertor;
    private Semaphore insertores = new Semaphore(1);                //Sincroniza el acceso a colaInsertor
    private Semaphore extractores = new Semaphore(1);               //Sincroniza el acceso a colaExtractor
    
    public BufferOscilante(Lista extraer, Lista insertar){
        colaExtractor = extraer;
        colaInsertor = insertar;
    }
    
    public void oscilar(){
        System.out.println("Oscilando");
        Lista listaTemp = colaExtractor;
        colaExtractor = colaInsertor;
        colaInsertor = listaTemp;
        insertores.release();
        extractores.release();
    }
    
    public void insertar(){
        try {
            insertores.acquire();
        } catch (InterruptedException ex) {
            Logger.getLogger(BufferOscilante.class.getName()).log(Level.SEVERE, null, ex);
        }
        colaInsertor.insertar(new Random().nextInt(500), colaInsertor.longitud() + 1);  //Añade un entero aleatorio al final de la cola
        //System.out.println(colaInsertor.toString());                          //Para pruebas, imprime el contenido de la Lista
        insertores.release();
    }
    
    public void extraer(){
        try {            
            extractores.acquire();
            if(!(colaExtractor.esVacia())){
                colaExtractor.eliminar(new Random().nextInt(colaExtractor.longitud()) + 1); //Elimina un entero aleatorio de la cola
                //System.out.println(colaExtractor.toString());                 //Para pruebas, imprime el contenido de la Lista
                if(colaExtractor.esVacia()) System.out.println("La cola de extraccion esta vacia");
                else System.out.println("La cola de extraccion no esta vacia");
                extractores.release();
            }
            else{
                insertores.acquire();
                if(!(colaInsertor.esVacia())) oscilar();                            
            }
        } catch (InterruptedException ex) {
            Logger.getLogger(BufferOscilante.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}