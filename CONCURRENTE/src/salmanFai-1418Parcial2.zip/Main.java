/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salmanFaiParcial2;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Admin
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
        int ejercicio = 2;
        switch (ejercicio){
            case 1:
                int numeroHilosInsertores = 5;
                int numeroHilosExtractores = 5;
                BufferOscilante buffer = new BufferOscilante(new Lista(), new Lista());
                for(int i = 0; i < numeroHilosInsertores; i++) new Thread(new Insertor(buffer), "Insertor " + i).start();               
                for(int i = 0; i < numeroHilosExtractores; i++) new Thread(new Extractor(buffer), "Extractor " + i).start();
                break;
                
           case 2:               
               int numeroDeAutos = 30;
               Transbordador transbordador = new Transbordador();
               new Thread(transbordador).start();
               for(int i = 0; i < numeroDeAutos; i++) new Thread(new Auto(transbordador), "Auto " + i).start();
               break;      
        }
    }        
}
