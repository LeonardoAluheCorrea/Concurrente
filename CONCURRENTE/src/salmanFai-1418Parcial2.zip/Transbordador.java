/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salmanFaiParcial2;

import java.util.Random;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Admin
 */
public class Transbordador implements Runnable{
    private int autosParaCruzar = 10;    
    private boolean cruzando = false;                                             //Si el barco esta cruzando el rio, o del otro lado 
    private final Object monitorTransbordador = new Object();                     //Este monitor es del transbordador en si, lo pone a dormir cuando no esta cruzando
    private final Object monitorAutosEsperandoSubir = new Object();               //Este monitor es de los autos esperando para subir al transbordador, los pone a dormir si no pudieron subir
    private final ReentrantLock modificarTransbordador = new ReentrantLock();     //Tambien se hace uso de un monitor sobre transbordador en si, utilizado para los autos que estan dentro del mismo. Los pone a dormir una vez subieron
    
    public void run(){
        while(true){
            if(autosParaCruzar == 0){
                ir();                
                volver();
            }
            else{
                try {
                    synchronized(monitorTransbordador){
                        System.out.println("Transbordador esperando que mas autos suban");
                        monitorTransbordador.wait();                        
                    }
                } catch (InterruptedException ex) {
                    Logger.getLogger(Transbordador.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
    public void subir(Auto autoASubir){
        modificarTransbordador.lock();
        try {
            if(autosParaCruzar > 0 && !cruzando){
                System.out.println(Thread.currentThread().getName() + " subio");
                autosParaCruzar--;
                autoASubir.subio(true);
                if(autosParaCruzar == 0){
                    synchronized (monitorTransbordador){            //Si el barco esta lleno, lo notifica para zarpar
                        monitorTransbordador.notify();                        
                    }
                }
                modificarTransbordador.unlock();
                synchronized(this){                                 //El auto que acaba de subir espera para que lo lleven al otro lado del rio
                    wait();                    
                }
            }
            else{
                synchronized(monitorAutosEsperandoSubir){
                    modificarTransbordador.unlock();
                    monitorAutosEsperandoSubir.wait();               //Los autos que no pudieron subir esperan a que vuelva el barco
                }
            }
        } catch (InterruptedException ex) {
            Logger.getLogger(Transbordador.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void bajar(){                     //No es necesario el uso de modificarTransbordador porque salen de a uno, el que sale le avisa al proximo
        System.out.println(Thread.currentThread().getName() + " baja");
        autosParaCruzar--;
        if(autosParaCruzar == 0){
            synchronized(monitorTransbordador){                 //Si no quedan autos en el barco, lo notifica
                monitorTransbordador.notify();
            }
        }
        else {
            synchronized(this){                                 //Avisa al proximo auto para bajar
                notify();                
            }
        }
    }
    
    private void ir(){
        cruzando = true;
        autosParaCruzar = 10;
        System.out.println("Transbordador cruzando");
        try {
            Thread.sleep(new Random().nextInt(3000));           
            synchronized(this){                                 //Avisa a un auto que ya puede bajarse
                notify();
            }
            synchronized(monitorTransbordador){                 //El barco espera a que se bajen todos los autos
                monitorTransbordador.wait();                
            }            
        } catch (InterruptedException ex) {
            Logger.getLogger(Transbordador.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    private void volver() {
        System.out.println("Transbordador volviendo");
        try {
            Thread.sleep(new Random().nextInt(3000));           //Simula el tiempo para cruzar el rio
            cruzando = false;
            autosParaCruzar = 10;
            synchronized(monitorAutosEsperandoSubir){           //Le avisa a los autos esperando en el muelle que hay lugar
                monitorAutosEsperandoSubir.notifyAll();
            }
        } catch (InterruptedException ex) {
            Logger.getLogger(Transbordador.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}